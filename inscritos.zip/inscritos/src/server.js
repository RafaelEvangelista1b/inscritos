// server.js
require('dotenv').config();
const express = require('express');
const { createClient } = require('@supabase/supabase-js');

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3000;
const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_KEY = process.env.SUPABASE_KEY;

if (!SUPABASE_URL || !SUPABASE_KEY) {
  console.error('Configure SUPABASE_URL e SUPABASE_KEY no .env');
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);
const TABLE = 'inscritos';

/* ------------------------
   ROTAS CRUD
   ------------------------ */

// GET /inscritos  -> lista (com paginação simples)
app.get('/inscritos', async (req, res) => {
  try {
    const { page = 1, per_page = 50, q } = req.query;
    const from = (page - 1) * per_page;
    const to = from + (+per_page) - 1;

    let query = supabase.from(TABLE).select('*').order('data_inscricao', { ascending: false }).range(from, to);

    if (q) {
      // busca simples por nome ou email (ILIKE)
      query = supabase
        .from(TABLE)
        .select('*')
        .or(`nome.ilike.*${q}*,email.ilike.*${q}*`)
        .order('data_inscricao', { ascending: false })
        .range(from, to);
    }

    const { data, error } = await query;
    if (error) return res.status(500).json({ error: error.message });
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /inscritos/:id
app.get('/inscritos/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { data, error } = await supabase.from(TABLE).select('*').eq('id', id).single();
    if (error) {
      if (error.code === 'PGRST116' || error.message.includes('No rows')) return res.status(404).json({ error: 'Inscrito não encontrado' });
      return res.status(500).json({ error: error.message });
    }
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /inscritos
app.post('/inscritos', async (req, res) => {
  try {
    const { nome, email, telefone, origem, interesse, notas, confirmado } = req.body;
    if (!nome || !email) return res.status(400).json({ error: 'nome e email são obrigatórios' });

    const payload = { nome, email, telefone, origem, interesse, notas, confirmado };
    const { data, error } = await supabase.from(TABLE).insert(payload).select().single();
    if (error) {
      // conflito de email
      return res.status(400).json({ error: error.message });
    }
    res.status(201).json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /inscritos/:id  (atualiza parcialmente)
app.put('/inscritos/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const updates = { ...req.body, updated_at: new Date().toISOString() };
    const { data, error } = await supabase.from(TABLE).update(updates).eq('id', id).select().single();
    if (error) {
      if (error.code === 'PGRST116' || error.message.includes('No rows')) return res.status(404).json({ error: 'Inscrito não encontrado' });
      return res.status(400).json({ error: error.message });
    }
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /inscritos/:id
app.delete('/inscritos/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { data, error } = await supabase.from(TABLE).delete().eq('id', id).select().single();
    if (error) {
      if (error.code === 'PGRST116' || error.message.includes('No rows')) return res.status(404).json({ error: 'Inscrito não encontrado' });
      return res.status(500).json({ error: error.message });
    }
    res.json({ message: 'Inscrito deletado', deleted: data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* rota health */
app.get('/', (req, res) => res.send('API Inscritos funcionando'));

app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));
