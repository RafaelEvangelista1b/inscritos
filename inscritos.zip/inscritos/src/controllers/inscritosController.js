const supabase = require('../config/supabaseClient');
const TABLE = 'inscritos';

module.exports = {

  async listar(req, res) {
    const { data, error } = await supabase.from(TABLE).select('*').order('data_inscricao', { ascending: false });

    if(error) return res.status(500).json({ error: error.message });
    return res.json(data);
  },

  async obterPorId(req, res) {
    const { id } = req.params;
    const { data, error } = await supabase.from(TABLE).select('*').eq('id', id).single();

    if(error) return res.status(404).json({ error: "Inscrito não encontrado" });
    res.json(data);
  },

  async criar(req, res) {
    const { nome, email, telefone, origem, interesse, notas, confirmado } = req.body;

    if (!nome || !email) return res.status(400).json({ error: "Nome e Email são obrigatórios!" });

    const { data, error } = await supabase.from(TABLE)
      .insert({ nome, email, telefone, origem, interesse, notas, confirmado })
      .select().single();

    if(error) return res.status(400).json({ error: error.message });
    res.status(201).json(data);
  },

  async atualizar(req, res) {
    const { id } = req.params;
    const updates = { ...req.body, updated_at: new Date() };

    const { data, error } = await supabase.from(TABLE)
      .update(updates)
      .eq('id', id)
      .select().single();

    if(error) return res.status(400).json({ error: "Erro ao atualizar" });
    res.json(data);
  },

  async deletar(req, res) {
    const { id } = req.params;

    const { data, error } = await supabase.from(TABLE)
      .delete()
      .eq('id', id)
      .select().single();

    if(error) return res.status(400).json({ error: "Erro ao deletar" });
    res.json({ mensagem: "Inscrito removido com sucesso", apagado: data });
  }

};
